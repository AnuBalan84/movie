var React=require('react');
var ReactDOM=require('react-dom');
var $=require('../vendor/jquery');

var DisplayFav=React.createClass({

   getInitialState : function()
   {
    return({data :[]});
   },

   update : function()
    {
      var query=ReactDOM.findDOMNode(this.refs.film).value;
      this.props.obj.Title=query;

      $.ajax({
      type : 'PUT',
     	dataType:'json',
      data: this.props.obj,
      url:'http://localhost:8080/movie/update' ,
     	success:function(data){
     	  console.log("success");
     	}.bind(this),
      error:function(xhr,status,err){
        console.error(this.props.url,status,err.toString());
      }.bind(this)
     });
   },

   delete : function()
   {
     $.ajax({
     type : 'DELETE',
     dataType:'json',
     data: this.props.obj,
     url:'http://localhost:8080/movie/delete',
     success:function(){
       console.log('success');
     }.bind(this),
     error:function(xhr,status,err){
       console.error(this.state.url,status,err.toString());
     }.bind(this)
    });
   },

  render:function()
  {
    return(
      <div className="content">
        <div className="row">

          <div className="col-lg-3">
            <div className="thumbnail">
            <img src={this.props.obj.Poster} alt="image"/>
          </div>
        </div>

        <div className="col-lg-9">
          <div className="list-group">
            <h2 className="list-group-item-text">Movie Title :<b>{this.props.obj.Title}</b></h2>
            <h2 className="list-group-item-text">Year:{this.props.obj.Year}</h2>
            <h3 className="list-group-item-text">Id:{this.props.obj.imdbID}</h3>
            <button type="button" className="btn btn-danger" onClick={this.delete}>Delete</button>
            &nbsp; &nbsp;
            <a href="#mymodal" role="button" className="btn btn-success" data-toggle="modal">Update</a>
            <div className="modal fade" id="mymodal">
                <div className="modal-dialog">
                  <div className="modal-content">

                    <div className="modal-header">
                      <button className="close" data-dismiss="modal">&times;</button>
                      <h4 className="modal-title">Update Movie</h4>
                    </div>

                    <div className="modal-body">
                      <form className="form-horizontal">

                        <div className="form-group">
                          <label className="col-lg-2 control-label" >Name</label>
                          <div className="col-lg-10">
                            <input type="text" className="form-control" id="name" refs="film" placeholder="Name" />
                          </div>
                        </div>

                        <div className="form-group">
                          <label className="col-lg-2 control-label" >IMDBid</label>
                          <div className="col-lg-10">
                            <input type="text" className="form-control" id="IMDBid" refs="id" placeholder="IMDBid" />
                          </div>
                        </div>
                          <button type="submit" class="btn btn-success pull-right" onClick={this.update}>Submit</button>
                      </form>
                    </div>

                  </div>
                </div>
            </div>
          </div>
        </div>

      </div>
    </div>
    )
  }
});

module.exports=DisplayFav;
